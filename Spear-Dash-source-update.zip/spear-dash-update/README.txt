Spear Dash Mod - source update for Minecraft 26.2

This is source code, not an installable mod JAR.

Copy the files into the matching paths in your GitHub repository. Replace
SpearDashClientMod.java and fabric.mod.json. Add the other Java, mixin JSON,
and language files at the paths shown in this archive. Keep existing project
files such as build.gradle, gradle.properties, and the Gradle wrapper.

In Minecraft Controls, bind "Toggle spear dash assist" (default G). With the
assist ON, click attack while a Lunge-enchanted spear is somewhere in the
hotbar. The mod attempts one spear jab per click and returns to the previously
selected slot. Keep a different item selected so its attack cooldown can be
used by the attribute swap.

This relies on an unsupported Minecraft packet timing behavior. Some servers
or anti-cheat systems block it, and a future game update can change it. The
server must allow the behavior. Java 25 and the project's Fabric API / Loader
versions are required.

Implementation inspiration: Attribute Swap, CC0-1.0, by Kavi Bhushan:
https://github.com/kaavi-pixel/attribute-swap/tree/mc/26.2
