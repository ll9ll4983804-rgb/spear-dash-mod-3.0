package com.ayman.speardash;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.Connection;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.core.Holder;
import net.minecraft.world.phys.HitResult;
import com.ayman.speardash.mixin.MinecraftInvoker;
import com.ayman.speardash.mixin.MultiPlayerGameModeInvoker;

/** Performs a spear jab with the selected item's current attack cooldown. */
public final class SpearDashSwap {
    private SpearDashSwap() {}

    private static Connection batching;

    public static boolean isBatching(Connection connection) {
        return batching != null && batching == connection;
    }

    /** Called before vanilla consumes the attack click. */
    public static void handleKeys(Minecraft minecraft) {
        if (minecraft.player == null) return;

        while (SpearDashClientMod.TOGGLE_KEY.consumeClick()) {
            SpearDashClientMod.enabled = !SpearDashClientMod.enabled;
            minecraft.player.sendOverlayMessage(
                    net.minecraft.network.chat.Component.literal(
                            "Spear Dash: " + (SpearDashClientMod.enabled ? "ON" : "OFF")));
        }

        if (!SpearDashClientMod.enabled || minecraft.options == null
                || minecraft.gameMode == null || minecraft.hitResult == null
                || minecraft.player.isSpectator() || minecraft.player.isUsingItem()) return;

        int spearSlot = findLungeSpear(minecraft);
        if (spearSlot < 0) return; // Leave the click to vanilla if no Lunge spear is in the hotbar.

        while (minecraft.options.keyAttack.consumeClick()) {
            swapAndJab(minecraft, spearSlot);
        }
    }

    private static int findLungeSpear(Minecraft minecraft) {
        LocalPlayer player = minecraft.player;
        if (player == null || player.level().registryAccess() == null) return -1;

        Inventory inventory = player.getInventory();
        int heldSlot = inventory.getSelectedSlot();
        var enchantmentRegistry = player.level().registryAccess()
                .lookupOrThrow(net.minecraft.core.registries.Registries.ENCHANTMENT);
        Holder<Enchantment> lunge = enchantmentRegistry.getOrThrow(Enchantments.LUNGE);

        for (int slot = 0; slot < Inventory.getSelectionSize(); slot++) {
            if (slot == heldSlot) continue;
            ItemStack stack = inventory.getItem(slot);
            if (!stack.has(DataComponents.PIERCING_WEAPON)) continue;
            var enchantments = stack.get(DataComponents.ENCHANTMENTS);
            if (enchantments != null && enchantments.getLevel(lunge) > 0) return slot;
        }
        return -1;
    }

    private static void swapAndJab(Minecraft minecraft, int spearSlot) {
        LocalPlayer player = minecraft.player;
        if (player == null || minecraft.gameMode == null || minecraft.hitResult == null) return;
        if (player.isSpectator() || player.isUsingItem()) return;

        Inventory inventory = player.getInventory();
        int originalSlot = inventory.getSelectedSlot();
        if (originalSlot == spearSlot) return;

        HitResult crosshair = minecraft.hitResult;
        ClientPacketListener listener = minecraft.getConnection();
        batching = listener == null ? null : listener.getConnection();

        try {
            // Send spear selection and jab together, then immediately restore the original slot.
            inventory.setSelectedSlot(spearSlot);
            ((MinecraftInvoker) minecraft).spearDash$startAttack();
            minecraft.hitResult = crosshair;
        } finally {
            if (inventory.getSelectedSlot() != originalSlot) {
                inventory.setSelectedSlot(originalSlot);
                ((MultiPlayerGameModeInvoker) minecraft.gameMode).spearDash$sendSelectedSlot();
            }
            minecraft.hitResult = crosshair;
            Connection connection = batching;
            batching = null;
            if (connection != null) connection.flushChannel();
        }
    }
}
