package com.ayman.speardash;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SpearDashClientMod implements ClientModInitializer {
    public static final String MOD_ID = "spear_dash_mod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static KeyMapping TOGGLE_KEY;
    public static boolean enabled = false;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "controls"));
        TOGGLE_KEY = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.spear_dash_mod.toggle",
                InputConstants.Type.KEYSYM,
                InputConstants.KEY_G,
                category,
                0));
        LOGGER.info("Spear Dash Mod initialized. Press G to toggle dash assist.");
    }
}
