package com.ayman.speardash.mixin;

import com.ayman.speardash.SpearDashSwap;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Inject(method = "handleKeybinds", at = @At("HEAD"))
    private void spearDash$handleKeys(CallbackInfo callback) {
        SpearDashSwap.handleKeys((Minecraft) (Object) this);
    }
}
