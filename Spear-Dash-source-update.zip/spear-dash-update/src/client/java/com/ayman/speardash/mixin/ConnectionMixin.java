package com.ayman.speardash.mixin;

import com.ayman.speardash.SpearDashSwap;
import net.minecraft.network.Connection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Connection.class)
public abstract class ConnectionMixin {
    @ModifyVariable(
            method = "send(Lnet/minecraft/network/protocol/Packet;Lio/netty/channel/ChannelFutureListener;Z)V",
            at = @At("HEAD"),
            argsOnly = true)
    private boolean spearDash$batchPackets(boolean flush) {
        return flush && !SpearDashSwap.isBatching((Connection) (Object) this);
    }
}
